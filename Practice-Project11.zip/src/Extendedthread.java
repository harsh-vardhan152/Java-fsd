package practiceproject;

public class Extendedthread extends Thread{
	public void run()
 	{
  		System.out.println("Thread is running by using extend");
}
 	public static void main( String args[] )
 	{
 		Extendedthread mt = new  Extendedthread();
  		mt.start();
  		
  		mt.run();
 	}
}

