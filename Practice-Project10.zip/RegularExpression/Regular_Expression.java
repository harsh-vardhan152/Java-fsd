package RegularExpression;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Regular_Expression {
	public static void main(String args[]) 
	{
		String s = "[A-Z0-9@ ]+";
		
		Scanner sc = new Scanner(System.in);
		  System.out.println("Enter specific string  ");
		  String find = sc.nextLine();
	    Pattern pattern = Pattern.compile(s);  
	    
	    Matcher matcher = pattern.matcher(find); 
	    while(matcher.find()) 
	    {
	    	System.out.println(find.substring(matcher.start(),matcher.end()));
	    }
	}

}