package map;
import java.util.*;
public class MapImplementation {

	public static void main(String[] args) {
		HashMap<String,String> hm=new HashMap<String,String>();      
	      hm.put("R","Raj");    
	      hm.put("S","Shayam");    
	      hm.put("Ra","Raju");  
	      hm.put("So","sonuy");
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	     
	       
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(54,"kanhiya");  
	      ht.put(67,"rk");  
	      ht.put(78,"pk");  
	      ht.put(79,"Jk");  

	      System.out.println("\nThe elements of HashTable are ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	     
	      
	      TreeMap<Integer,Integer> tm=new TreeMap<Integer,Integer>();    
	      tm.put(6,45);    
	      tm.put(5,05); 
	      tm.put(2,123);
	      tm.put(56,456);       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:tm.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      


	}

}
