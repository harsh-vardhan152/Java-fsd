package exceptionhandling;
class InvalidAgeException1 extends Exception{

	public String toString() {
		return "You are not eligible for vote";
	}
	
}
public class CustomException {
	static void  validate(int balance)throws InvalidAgeException1{
		if(balance <18){
			throw new InvalidAgeException1();
		}
		else
			System.out.println("welcome to vote");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			validate(15);
		}
		catch(InvalidAgeException1 e){
			System.out.println(e);
		}

	}

}