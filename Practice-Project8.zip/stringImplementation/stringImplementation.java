package stringImplementation;

public class stringImplementation {

	public static void main(String[] args) {
System.out.println("Conversion of Strings to StringBuffer ");
		
		String str = "Hello"; 
       
        StringBuffer sbr = new StringBuffer(str); 
     
        
        System.out.println(sbr); 
       System.out.println("---------------------------------");
        System.out.println("Conversion of Strings to StringBuilder ");
        StringBuilder sbl = new StringBuilder(str); 
    
        sbl.append("bye");
        System.out.println(sbl);              		
        System.out.println("---------------------------------");
        System.out.println("Some pre define function of String");
		String sl= "hello";
		System.out.println("find length of the String: "+sl.length());

		
		
		String s="world";
		System.out.println("substring from string s from index 3: "+s.substring(3));

		
		String s1="hi";
		String s2="He";
		System.out.println("comparision of two string s1 and s2: "+s1.compareTo(s2));

		
		String s3="";
		System.out.println("check string is empty or not: "+s3.isEmpty());
		String s4="welcome";
		System.out.println("covert the String into upper case: "+s4.toUpperCase());
		
		String s5="WELCOME";
		System.out.println("covert the String into lower case: "+s5.toLowerCase());
		
		String s6="byo";
		String replace=s6.replace('o', 'e');
		System.out.println("replace the character from string s6: "+replace);

		
		String s7="Welcome";
		String s8="WeLcOmE";
		System.out.println("check two string are equal or not :"+s7.equals(s8));
 
		
		
		
		

	}

}
