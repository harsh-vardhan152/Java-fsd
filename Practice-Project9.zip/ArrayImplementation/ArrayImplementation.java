package ArrayImplementation;

public class ArrayImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("one-D Array");
		int arr[] = {1 , 2,3,4,5};
		System.out.println("size of the array is: "+arr.length);
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("the element in 1-D array are: "+arr[i]);
		}
		System.out.println("================================");
		System.out.println("MultiDimensional Array");
		int a[][]= {{1,2,3},{4, 5,6},{7,8,9}};
		for(int i=0;i<a.length;i++) 
		{
			for(int j=0;j<a[0].length;j++) 
			{
				System.out.print(a[i][j]+ " ");
			}
			System.out.println();
		}

	}

}

