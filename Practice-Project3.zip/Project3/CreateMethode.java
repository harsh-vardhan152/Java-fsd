package Method;

public class CreateMethode {
	int x=5;
	
	void addition(int a,int b) 
	{
	    System.out.println("additionof two number "+a+b);
	}
	int callByVlaue(int w) 
	
	{
		int y = w*10;
		return y;
	}
	void overload(int c) 
	{
		System.out.println(c+10);
		
	}
	void overload(String x) 
	{
		System.out.println(x);
	}
	
	
public static void main(String args[]) 
{
	CreateMethode obj  =  new CreateMethode();

	obj.addition(5, 6);
	System.out.println("Before operation value of x is "+obj.x);
	obj.callByVlaue(5);
	System.out.println("After operation value of data is "+obj.x);
	System.out.println("now here we are show method overloading");
	obj.overload(5);
	obj.overload("prince");

	
	}
}
